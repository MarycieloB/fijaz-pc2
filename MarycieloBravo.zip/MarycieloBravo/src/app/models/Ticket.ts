export class Ticket {
    idTicket: number = 0
    titleTicket: string = ""
    descriptionTicket: string = ""
    dateCreation: Date = new Date()
    dateClose: Date = new Date()
    statusTicket: boolean = false
    solutionTicket: string = ""
}
