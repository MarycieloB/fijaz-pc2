import { Routes } from '@angular/router';
import { Mhbohomecomponent } from './components/mhbohomecomponent/mhbohomecomponent';
import { Mhboticketcomponent } from './components/mhboticketcomponent/mhboticketcomponent';
import { MhboTicketList } from './components/mhboticketcomponent/mhboticket-list/mhboticket-list';
import { MhboTicketInsert } from './components/mhboticketcomponent/mhboticket-insert/mhboticket-insert';

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'mhbohome',
        pathMatch: 'full'
    },
    {
        path: 'mhbohome',
        component: Mhbohomecomponent
    },
    {
        path: 'mhbotickets',
        component: Mhboticketcomponent,
        children: [
            {
                path: 'listas',
                component: MhboTicketList
            },
            {
                path: 'nuevo',
                component: MhboTicketInsert
            }
        ]
    }
];
