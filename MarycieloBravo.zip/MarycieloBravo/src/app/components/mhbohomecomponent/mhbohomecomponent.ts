import { Component } from '@angular/core';

@Component({
  selector: 'app-mhbohomecomponent',
  imports: [],
  templateUrl: './mhbohomecomponent.html',
  styleUrl: './mhbohomecomponent.css',
})
export class Mhbohomecomponent {}
