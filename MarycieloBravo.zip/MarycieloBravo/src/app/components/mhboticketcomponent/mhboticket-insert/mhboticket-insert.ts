import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { Ticket } from '../../../models/Ticket';
import { Ticketservice } from '../../../services/ticketservice';
import { Router } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

@Component({
  selector: 'app-mhboticket-insert',
  imports: [
    MatInputModule,
    MatRadioModule,
    MatDatepickerModule,
    MatButtonModule,
    MatSnackBarModule,
    ReactiveFormsModule
  ],
  templateUrl: './mhboticket-insert.html',
  providers: [provideNativeDateAdapter()],
  styleUrl: './mhboticket-insert.css',
})
export class MhboTicketInsert implements OnInit {

  form: FormGroup = new FormGroup({})
  tic: Ticket = new Ticket()

  constructor(private tS: Ticketservice,
    private router: Router,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      title: ['', [Validators.required, Validators.maxLength(40)]],
      description: ['', [Validators.required, Validators.maxLength(400)]],
      dateCreation: ['', Validators.required],
      dateClose: ['', Validators.required],
      state: ['', Validators.required],
      solution: ['', [Validators.required, Validators.maxLength(400)]]
    }, { validators: this.validarFechas })
  }

  validarFechas(group: AbstractControl): ValidationErrors | null {
    const creacion = group.get('dateCreation')?.value
    const cierre = group.get('dateClose')?.value
    if (creacion && cierre && new Date(creacion) > new Date(cierre)) {
      return { fechasInvalidas: true }
    }
    return null
  }

  aceptar() {
    if (this.form.valid) {
      this.tic.titleTicket = this.form.value.title
      this.tic.descriptionTicket = this.form.value.description
      this.tic.dateCreation = this.form.value.dateCreation
      this.tic.dateClose = this.form.value.dateClose
      this.tic.statusTicket = this.form.value.state
      this.tic.solutionTicket = this.form.value.solution
      this.tS.insert(this.tic).subscribe({
        next: () => {
          this.snackBar.open('Registro exitoso', 'Cerrar', { duration: 3000 })
          this.form.reset()
          this.router.navigate(['/mhbotickets/nuevo'])
        }
      })
    } else {
      this.form.markAllAsTouched()
    }
  }

  cancelar() {
    this.router.navigate(['/mhbotickets/listas'])
  }
}
