import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { Ticket } from '../models/Ticket';

const base_url = environment.base

@Injectable({
  providedIn: 'root',
})
export class Ticketservice {
  private boUrl = `${base_url}/api-tickets`

  constructor(private http: HttpClient) { }

  list() {
    return this.http.get<Ticket[]>(`${this.boUrl}/lista`);
  }
  insert(boT: Ticket) {
    return this.http.post(`${this.boUrl}/nuevo`, boT)
  }
  delete(boId: number) {
    return this.http.delete(`${this.boUrl}/${boId}`, { responseType: 'text' })
  }
}
