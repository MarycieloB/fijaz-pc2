import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Mhbomenucomponent } from './components/mhbomenucomponent/mhbomenucomponent';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Mhbomenucomponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('MarycieloBravo');
}
