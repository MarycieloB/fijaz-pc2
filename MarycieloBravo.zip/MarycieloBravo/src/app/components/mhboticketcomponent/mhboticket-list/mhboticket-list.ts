import { Component, OnInit } from '@angular/core';
import { Ticket } from '../../../models/Ticket';
import { Ticketservice } from '../../../services/ticketservice';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-mhboticket-list',
  imports: [
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatSnackBarModule,
    DatePipe
  ],
  templateUrl: './mhboticket-list.html',
  providers: [provideNativeDateAdapter()],
  styleUrl: './mhboticket-list.css',
})
export class MhboTicketList implements OnInit {
  boLista: Ticket[] = []
  boFiltradas: Ticket[] = []
  boPaginadas: Ticket[] = []

  boPageSize: number = 5
  boPageIndex: number = 0

  constructor(private tS: Ticketservice, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.cargar()
  }

  cargar() {
    this.tS.list().subscribe({
      next: (data) => {
        this.boLista = data
        this.boFiltradas = data
        this.boPageIndex = 0
        this.actualizarPagina()
      }
    })
  }

  filtrar(fecha: any) {
    if (fecha) {
      const buscada = new Date(fecha).toDateString()
      this.boFiltradas = this.boLista.filter(
        t => new Date(t.dateCreation).toDateString() === buscada
      )
    } else {
      this.boFiltradas = this.boLista
    }
    this.boPageIndex = 0
    this.actualizarPagina()
  }

  cambiarPagina(e: PageEvent) {
    this.boPageSize = e.pageSize
    this.boPageIndex = e.pageIndex
    this.actualizarPagina()
  }

  actualizarPagina() {
    const inicio = this.boPageIndex * this.boPageSize
    const fin = inicio + this.boPageSize
    this.boPaginadas = this.boFiltradas.slice(inicio, fin)
  }

  eliminar(boId: number) {
    this.tS.delete(boId).subscribe({
      next: () => {
        this.snackBar.open('Se eliminó correctamente', 'Cerrar', { duration: 3000 })
        this.cargar()
      }
    })
  }
}
