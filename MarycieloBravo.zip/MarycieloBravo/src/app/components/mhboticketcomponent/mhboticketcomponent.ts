import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RouterOutlet } from '@angular/router';
import { MhboTicketList } from './mhboticket-list/mhboticket-list';

@Component({
  selector: 'app-mhboticketcomponent',
  imports: [RouterOutlet, MhboTicketList],
  templateUrl: './mhboticketcomponent.html',
  styleUrl: './mhboticketcomponent.css',
})
export class Mhboticketcomponent {
  constructor(public route: ActivatedRoute) { }
}
